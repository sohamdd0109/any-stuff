# 2d-minecraft-by-griffpatch

This project is made by Griffpatch on scratch URL-https://scratch.mit.edu/projects/10128407/
I have just turned it into HTML.

How to play?

[1 to 9] - Select Item   ?[Click] - Place or Mine
[WASD] - Move / Jump  [E] - Open/Close Inventory
[E+hover] - Open / Close Chest, Crafting Table, Door
[Space] - Drop single tile from a stack while dragging.
[F] - Eat food      ?[N] - Label a sign or chest
[Q] - Drop item      [P] - Pause / Unpause
[T] - Talk / Command   ?[O] - Save your game
[M] - Music / Sounds   [Shift] - Sprint



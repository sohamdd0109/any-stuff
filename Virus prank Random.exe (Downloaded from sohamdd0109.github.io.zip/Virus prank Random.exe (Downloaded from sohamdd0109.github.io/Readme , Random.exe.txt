Instructions---

Changing the icon:
Click on the Random.exe shortcut file. Right click. Click properties. Click change icon. Click browse. Then select the favicon.ico file.

-------------------------------------------------------------
https://sohamdd0109.github.io
-------------------------------------------------------------
